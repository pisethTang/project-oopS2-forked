#include "superTest.h"

int main() {
    super_test st;
    st.run_all_tests();
    
    return 0;
}