#ifndef COWSTEST_H
#define COWSTEST_H

#include <iostream>
#include <limits>
#include "Cows.h"

class test_cows {
public:
    void runCowsTests();

private:
    void testConstructor();

};

#endif
