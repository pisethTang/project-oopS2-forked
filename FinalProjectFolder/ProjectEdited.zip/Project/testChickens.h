#ifndef COWSTEST_H
#define COWSTEST_H

#include <iostream>
#include <limits>
#include "Chickens.h"

class test_chickens {
public:
    void runChickensTests();
    
private:
    void testConstructor();
};

#endif
