#ifndef COWSTEST_H
#define COWSTEST_H

#include <iostream>
#include <limits>
#include "Sheep.h"

class test_sheep{
public:
    void runSheepTests();

private:
    void testConstructor();
};

#endif
