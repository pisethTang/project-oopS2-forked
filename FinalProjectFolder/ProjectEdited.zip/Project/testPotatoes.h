#ifndef TESTPOTATOES_H
#define TESTPOTATOES_H




#include <iostream>
#include <limits>
#include "Potatoes.h"

class test_potatoes{
public:
    void runPotatoesTests();

private:
    void testConstructor();
   
};

#endif
