#ifndef CARROTSTEST_H
#define CARROTSTEST_H


#include <iostream>
#include <limits>
#include "Carrots.h"

class test_carrots{
public:
    void runCarrotsTests();

private:
    void testConstructor();
};

#endif
