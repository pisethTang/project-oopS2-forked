#ifndef SUPERTEST_H
#define SUPERTEST_H

// include several header files of test files
// #include "testCrops"
// #include "testAnimals"




class super_test{
    public:
        void run_all_tests();
};  


#endif