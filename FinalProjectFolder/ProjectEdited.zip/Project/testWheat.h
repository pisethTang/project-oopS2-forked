#ifndef TESTWHEAT_H
#define TESTWHEAT_H




#include <iostream>
#include <limits>
#include "Wheat.h"

class test_wheat{
public:
    void runWheatTests();
private:
    void testConstructor();

};

#endif
